#include <rtthread.h>
#include "dysv17f.h"
#include "key.h"
#include "ld3320.h"

/* ����ʶ�������������� */
const VOICE voice_group[VOICE_NUM]={
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x30, 0x31, 0x2A, 0x4D, 0x50, 0x33, 0x77},"DING_DING"             ,""},                        //000-->������ʾ��
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x30, 0x32, 0x2A, 0x4D, 0x50, 0x33, 0x78},"WIFI_CONNECT_SUCCESS"  ,""},                        //001-->WIFI���ӳɹ�
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x30, 0x33, 0x2A, 0x4D, 0x50, 0x33, 0x79},"WIFI_CONNECT_FAILED"   ,""},                        //002-->WIFI����ʧ��
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x30, 0x34, 0x2A, 0x4D, 0x50, 0x33, 0x7A},"AIR_POWER_ON"          ,"da kai kong tiao"},        //003-->�򿪿յ�
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x30, 0x35, 0x2A, 0x4D, 0x50, 0x33, 0x7B},"AIR_POWER_OFF"         ,"guan bi kong tiao"},       //004-->�رտյ�
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x30, 0x36, 0x2A, 0x4D, 0x50, 0x33, 0x7C},"AIR_WIND_DIRECT_ON"    ,"da kai sao feng"},         //005-->��ɨ��
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x30, 0x37, 0x2A, 0x4D, 0x50, 0x33, 0x7D},"AIR_WIND_DIRECT_OFF"   ,"guan bi sao feng"},        //006-->�ر�ɨ��
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x30, 0x38, 0x2A, 0x4D, 0x50, 0x33, 0x7E},"LED_ON"                ,"da kai ye deng"},          //007-->��Сҹ��
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x30, 0x39, 0x2A, 0x4D, 0x50, 0x33, 0x7F},"LED_OFF"               ,"guan bi ye deng"},         //008-->�ر�Сҹ��
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x31, 0x30, 0x2A, 0x4D, 0x50, 0x33, 0x77},"AIR_LIGHT_ON"          ,"da kai deng guang"},       //009-->�򿪿յ��ƹ�
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x31, 0x31, 0x2A, 0x4D, 0x50, 0x33, 0x78},"AIR_LIGHT_OFF"         ,"guan bi deng guang"},      //010-->�رտյ��ƹ�
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x31, 0x32, 0x2A, 0x4D, 0x50, 0x33, 0x79},"AIR_MODE_AUTO"         ,"zi dong mo shi"},          //011-->�Զ�ģʽ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x31, 0x33, 0x2A, 0x4D, 0x50, 0x33, 0x7A},"AIR_MODE_COLD"         ,"zhi leng mo shi"},         //012-->����ģʽ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x31, 0x34, 0x2A, 0x4D, 0x50, 0x33, 0x7B},"AIR_MODE_DRY"          ,"chu shi mo shi"},          //013-->��ʪģʽ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x31, 0x35, 0x2A, 0x4D, 0x50, 0x33, 0x7C},"AIR_MODE_WIND"         ,"song feng mo shi"},        //014-->�ͷ�ģʽ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x31, 0x36, 0x2A, 0x4D, 0x50, 0x33, 0x7D},"AIR_MODE_HOT"          ,"zhi re mo shi"},           //015-->����ģʽ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x31, 0x37, 0x2A, 0x4D, 0x50, 0x33, 0x7E},"TIMING_ONE"            ,"ding shi yi xiao shi"},    //016-->��ʱһСʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x31, 0x38, 0x2A, 0x4D, 0x50, 0x33, 0x7F},"TIMING_TWO"            ,"ding shi liang xiao shi"}, //017-->��ʱ��Сʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x31, 0x39, 0x2A, 0x4D, 0x50, 0x33, 0x80},"TIMING_THREE"          ,"ding shi san xiao shi"},   //018-->��ʱ��Сʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x32, 0x30, 0x2A, 0x4D, 0x50, 0x33, 0x78},"TIMING_FOUR"           ,"ding shi shi xiao shi"},   //019-->��ʱ��Сʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x32, 0x31, 0x2A, 0x4D, 0x50, 0x33, 0x79},"TIMING_FIVE"           ,"ding shi wu xiao shi"},    //020-->��ʱ��Сʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x32, 0x32, 0x2A, 0x4D, 0x50, 0x33, 0x7A},"TIMING_SIX"            ,"ding shi liu xiao shi"},   //021-->��ʱ��Сʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x32, 0x33, 0x2A, 0x4D, 0x50, 0x33, 0x7B},"TIMING_SEVEN"          ,"ding shi qi xiao shi"},    //022-->��ʱ��Сʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x32, 0x34, 0x2A, 0x4D, 0x50, 0x33, 0x7C},"TIMING_EIGHT"          ,"ding shi ba"},             //023-->��ʱ��Сʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x32, 0x35, 0x2A, 0x4D, 0x50, 0x33, 0x7D},"TIMING_NINE"           ,"ding shi jiu"},            //024-->��ʱ��Сʱ                                                         
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x32, 0x36, 0x2A, 0x4D, 0x50, 0x33, 0x7E},"INTERVAL_TIMING_ONE"   ,"jian ge yi xiao"},         //025-->�����ʱһСʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x32, 0x37, 0x2A, 0x4D, 0x50, 0x33, 0x7F},"INTERVAL_TIMING_TWO"   ,"jian ge liang xiao"},      //026-->�����ʱ��Сʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x32, 0x38, 0x2A, 0x4D, 0x50, 0x33, 0x80},"INTERVAL_TIMING_THREE" ,"jian ge san xiao"},        //027-->�����ʱ��Сʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x32, 0x39, 0x2A, 0x4D, 0x50, 0x33, 0x81},"INTERVAL_TIMING_FOUR"  ,"jian ge shi xiao"},        //028-->�����ʱ��Сʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x33, 0x30, 0x2A, 0x4D, 0x50, 0x33, 0x79},"INTERVAL_TIMING_FIVE"  ,"jian ge wu xiao"},         //029-->�����ʱ��Сʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x33, 0x31, 0x2A, 0x4D, 0x50, 0x33, 0x7A},"INTERVAL_TIMING_SIX"   ,"jian ge liu xiao"},        //030-->�����ʱ��Сʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x33, 0x32, 0x2A, 0x4D, 0x50, 0x33, 0x7B},"INTERVAL_TIMING_SEVEN" ,"jian ge qi xiao"},         //031-->�����ʱ��Сʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x33, 0x33, 0x2A, 0x4D, 0x50, 0x33, 0x7C},"INTERVAL_TIMING_EIGHT" ,"jian ge ba xiao"},         //032-->�����ʱ��Сʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x33, 0x34, 0x2A, 0x4D, 0x50, 0x33, 0x7D},"INTERVAL_TIMING_NINE"  ,"jian ge jiu xiao"},        //033-->�����ʱ��Сʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x33, 0x35, 0x2A, 0x4D, 0x50, 0x33, 0x7E},"REPLY_ONE"             ,"da li tong xue"},          //034-->
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x33, 0x36, 0x2A, 0x4D, 0x50, 0x33, 0x7F},"REPLY_TWO"             ,"da li da li"},             //035-->
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x33, 0x37, 0x2A, 0x4D, 0x50, 0x33, 0x80},"REPLY_THREE"           ,"da li"},                   //036-->
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x33, 0x39, 0x2A, 0x4D, 0x50, 0x33, 0x82},"REDUCE_TEMPERATURE"    ,"you dian re"},             //038-->�����¶�
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x34, 0x30, 0x2A, 0x4D, 0x50, 0x33, 0x7A},"INCREASE_TEMPERATURE"  ,"you dian leng"},           //039-->����¶�
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x34, 0x31, 0x2A, 0x4D, 0x50, 0x33, 0x7B},"CANCEL_TIMING"         ,"qu xiao"},                 //040-->ȡ����ʱ
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x34, 0x32, 0x2A, 0x4D, 0x50, 0x33, 0x7C},"NOT_RECOGNIZED"        ,""},                        //041-->û��ʶ��
{{0xAA, 0x08, 0x09, 0x02, 0x2F, 0x30, 0x33, 0x38, 0x2A, 0x4D, 0x50, 0x33, 0x81},"SLEEP"                 ,""},                        //037-->��˯����

}; 

/**
  ******************************************************************************
  * @name   : DYSV17F_Init
  * @brief  : ��������ģ�鴮�ڳ�ʼ��
  * @note   : 
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-04     YMH
  ******************************************************************************
 */
void DYSV17F_Init()
{
    GPIO_InitTypeDef GPIO_InitStrue;
    USART_InitTypeDef USART_InitStrue;
    NVIC_InitTypeDef NVIC_InitStructure;

    // ����ʹ��ʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
    USART_DeInit(USART2);  //��λ����2 -> ����û��

    // ��ʼ�����ڶ�ӦIO��  TX-PA2  RX-PA3
    GPIO_InitStrue.GPIO_Mode=GPIO_Mode_AF_PP;
    GPIO_InitStrue.GPIO_Pin=GPIO_Pin_2;
    GPIO_InitStrue.GPIO_Speed=GPIO_Speed_50MHz;
    GPIO_Init(GPIOA,&GPIO_InitStrue);

    GPIO_InitStrue.GPIO_Mode=GPIO_Mode_IN_FLOATING;
    GPIO_InitStrue.GPIO_Pin=GPIO_Pin_3;
    GPIO_Init(GPIOA,&GPIO_InitStrue);

    // ��ʼ������ģʽ״̬
    USART_InitStrue.USART_BaudRate=9600; // ������
    USART_InitStrue.USART_HardwareFlowControl=USART_HardwareFlowControl_None; // Ӳ��������
    USART_InitStrue.USART_Mode=USART_Mode_Tx|USART_Mode_Rx; // ���� ���� ģʽ��ʹ��
    USART_InitStrue.USART_Parity=USART_Parity_No; // û����żУ��
    USART_InitStrue.USART_StopBits=USART_StopBits_1; // һλֹͣλ
    USART_InitStrue.USART_WordLength=USART_WordLength_8b; // ÿ�η������ݿ���Ϊ8λ

    USART_Init(USART2,&USART_InitStrue);
    USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);//���������ж�
    USART_Cmd(USART2,ENABLE);//ʹ�ܴ���

    // ��ʼ���ж����ȼ�
    NVIC_InitStructure.NVIC_IRQChannel=USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority=1;
    NVIC_Init(&NVIC_InitStructure);
}

void USART2_IRQHandler(void)
{
    if(USART_GetITStatus(USART2,USART_IT_RXNE))
    {
        USART_ClearFlag(USART2,USART_FLAG_ORE);//�������ж�
    }
}

/**
  ******************************************************************************
  * @name   : DYSV17F_Play
  * @brief  : ������ģ�鷢��һ���ַ������������Ϣ
  * @note   : 
  * @param  : date:16λ�����ַ
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-04     YMH
  ******************************************************************************
 */
void DYSV17F_Play(const unsigned char *date)//�����ַ�����
{
    unsigned char i;
    for(i=0; i<13; i++)
    {
        rt_thread_udelay(50);
        USART_SendData(USART2,date[i]);
        while( (USART2->SR&0X40)==0 );//�ȴ�ǰ������ݷ������
    }
}

/**
  ******************************************************************************
  * @name   : Response_Sound
  * @brief  : Ӧ����Ч
  * @note   : 
  * @param  : buf�����ŵڼ�������
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-05     YMH
  ******************************************************************************
 */
void Response_Sound(uint8_t buf)
{
    rt_err_t result;
    result = rt_mq_send(&dysv17f_mq, &buf,sizeof(buf));
    if (result != RT_EOK)
    {
        rt_kprintf("[dysv17f_mq]:dysv17f_mq send ERR \n");
    }
}

/**
  ******************************************************************************
  * @name   : dysv17f_thread_entry
  * @brief  : DYSV17F�߳�
  * @note   : 
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-04     YMH
  ******************************************************************************
 */
void dysv17f_thread_entry(void* parameter)
{
    uint8_t buf=0;
    while(1)
    {
        if(rt_mq_recv(&dysv17f_mq, &buf, sizeof(buf), RT_WAITING_FOREVER) == RT_EOK)
        {
            rt_kprintf("[dysv17f_mq]:dysv17f thread take a dysv17f mq success.\n");
            play_status = PLAYING;   //���ڲ���,��ͣ����ʶ��
            KEY_LED = KEY_LED_OFF;
            DYSV17F_Play(voice_group[buf].voice_code);
            rt_kprintf("[%-16s]:DYSV17F_PLAY: %s.\n",rt_thread_self()->parameter,voice_group[buf].voice_name);
            rt_thread_mdelay(2500);   //�ӳٵȴ��������
            /* �ȴ������������,�ٽ�������ʶ��,�������,ָʾ������,��ʾ���Խ�������ʶ�� */
            play_status = PLAY_FINISHED;
            if(g_recognized_keywords == 1)   //�ж��Ƿ��Ѿ�ʶ�𵽻��Ѵ�
            {
                KEY_LED = KEY_LED_ON;
            }
        }
        else rt_kprintf("[dysv17f_mq]:dysv17f thread take a dysv17f mq failed.\n");
    }
}

