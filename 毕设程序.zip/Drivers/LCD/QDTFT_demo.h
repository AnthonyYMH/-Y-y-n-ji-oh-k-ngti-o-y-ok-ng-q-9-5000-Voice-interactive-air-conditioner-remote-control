#ifndef __QDTFT_DEMO_H
#define __QDTFT_DEMO_H 
#include "rtthread.h"

/* ��ѧѧУlogo */
#define SCHOOL_LOGO_X 26
#define SCHOOL_LOGO_Y 8
#define SCHOOL_BMP_X  75
#define SCHOOL_BMP_Y  75
/* ������Ŀ */
#define TOPIC_X  10
#define TOPIC_Y  92
/* ���� */
#define NAME_X   16
#define NAME_Y   111
/* WIFI_logo */
#define _WIFI_LOGO    1
#define WIFI_LOGO_X   0
#define WIFI_LOGO_Y   0
#define WIFI_BMP_X   15
#define WIFI_BMP_Y   14
/* ����ʱ�� */
#define _DATETIME    2
#define DATETIME_X   23
#define DATETIME_Y   2
/* ��Դ */
#define _AIR_POWER   3
#define AIR_POWER_X  6
#define AIR_POWER_Y  20
/* ɨ�� */
#define _SWEEP_WIND  4
#define SWEEP_WIND_X 70
#define SWEEP_WIND_Y 20
/* �ƹ� */
#define _LIGHT     5
#define LIGHT_X   6
#define LIGHT_Y   40
/* ģʽ */
#define _MODE     6
#define MODE_X    70
#define MODE_Y    40
/* ���� */
#define _WIND_SPEED     7
#define WIND_SPEED_X   6
#define WIND_SPEED_Y   60
/* �¶� */
#define _AIR_TEMP     8
#define AIR_TEMP_X   70
#define AIR_TEMP_Y   60
/* ��ʱ */
#define _TIMING     9
#define TIMING_X   6
#define TIMING_Y   80
/* �����ʱ */
#define INTERVAL_TIMING_X   70
#define INTERVAL_TIMING_Y   80
/* �����¶� */
#define _ROOM_TEMP_HUMI   10
#define ROOM_TEMP_X   6
#define ROOM_TEMP_Y   98
/* ����ʪ�� */
#define ROOM_HUMI_X   6
#define ROOM_HUMI_Y   112

extern struct rt_messagequeue lcd_refresh_mq;   //��Ϣ���п��ƿ�
extern rt_uint8_t lcd_refresh_msg_pool[16];   //��Ϣ�������õ��ķ�����Ϣ���ڴ��
extern rt_timer_t LCD_LED_Timer;   //LCD���ⶨʱ��

void Redraw_Mainmenu(void);
extern void showimage(uint8_t x_start,u16 y_start,u16 pic_x,u16 pic_y,
                      const unsigned char *p);
void QDTFT_Test_Demo(void);
extern void LCD_LED_Timeout(void* parameter);
extern void lcd_thread_entry(void* parameter);
extern void Startup_Screen(void);

#endif
