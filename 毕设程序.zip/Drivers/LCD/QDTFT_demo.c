/* Includes ------------------------------------------------------------------*/
#include <rtthread.h>
#include "stm32f10x.h"
#include "usart3.h"
#include "Lcd_Driver.h"
#include "GUI.h"
#include "Picture.h"
#include "QDTFT_demo.h"
#include "hdc1080.h"
#include "remote.h"

unsigned char Num[10]= {0,1,2,3,4,5,6,7,8,9};
void Redraw_Mainmenu(void)
{
    Lcd_Clear(GRAY0);

    Gui_DrawFont_GBK16(16,0,BLUE,GRAY0,"ȫ�����Ӽ���");
    Gui_DrawFont_GBK16(16,20,RED,GRAY0,"Һ�����Գ���");

    DisplayButtonUp(15,38,113,58); //x1,y1,x2,y2
    Gui_DrawFont_GBK16(16,40,YELLOW,GRAY0,"��ɫ������");

    DisplayButtonUp(15,68,113,88); //x1,y1,x2,y2
    Gui_DrawFont_GBK16(16,70,BLUE,GRAY0,"������ʾ����");

    DisplayButtonUp(15,98,113,118); //x1,y1,x2,y2
    Gui_DrawFont_GBK16(16,100,RED,GRAY0,"ͼƬ��ʾ����");
    rt_thread_mdelay(1500);
}

/**
  ******************************************************************************
  * @name   : showimage
  * @brief  : LCD��ʾͼƬ
  * @note   : ȡģ��ʽ��ˮƽɨ�� ������ ��λ��ǰ
  * @param  : x_start:ͼƬ��ʼ����-->X
            ��y_start:ͼƬ��ʼ����-->Y
            ��pic_x:ͼƬ����x
            ��pic_y:ͼƬ����y
            ��p:ͼƬ����
  * @retval :
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-20     YMH
  * V1.0.1       2020-02-25     YMH          ɾ����������
  ******************************************************************************
 */
void showimage(uint8_t x_start,u16 y_start,u16 pic_x,u16 pic_y,
               const unsigned char *p)
{
    uint16_t i;
    unsigned char picH,picL;
    //Lcd_Clear(WHITE); //����
    Lcd_SetRegion(x_start,y_start,(x_start+pic_x-1),(y_start+pic_y-1));		//��������
    for(i=0; i<(pic_x*pic_y); i++)
    {
        picL=*(p+i*2);	//���ݵ�λ��ǰ
        picH=*(p+i*2+1);
        LCD_WriteData_16Bit(picH<<8|picL);
    }
}

void QDTFT_Test_Demo(void)
{

}

/**
  ******************************************************************************
  * @name   : Startup_Screen
  * @brief  : ��������
  * @note   :
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-23     YMH
  ******************************************************************************
 */
void Startup_Screen(void)
{
    /* �������� */
    LCD_LED_SET;
    Lcd_Clear(WHITE);
    /* ��ʾѧУlogo */
    showimage(SCHOOL_LOGO_X,SCHOOL_LOGO_Y,SCHOOL_BMP_X,SCHOOL_BMP_Y,SCHOOL_LOGO);
    Gui_DrawFont_GBK12(TOPIC_X,TOPIC_Y,BLACK,WHITE,"���������յ�ң����");
    Gui_DrawFont_GBK12(NAME_X,NAME_Y,BLACK,WHITE,"��������������Ʒ");
}

/**
  ******************************************************************************
  * @name   : Refresh_LCD_Display
  * @brief  : LCDˢ����ʾ
  * @note   : ����lcd_refresh_mq��Ϣ���еõ������ݣ�ȥ����LCD��ʾ����
  * @param  : refresh_type: �������
  * @retval : 
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-24     YMH
  * V1.0.1       2020-02-24     YMH          ����Դ�ر�ʱ,ͬʱ���㶨ʱ������ʱ
  ******************************************************************************
 */
void Refresh_LCD_Display(uint8_t refresh_type)
{
    switch(refresh_type)
    {
    /* WIFI */
    case _WIFI_LOGO:
        if(g_wifi_sta)showimage(WIFI_LOGO_X,WIFI_LOGO_Y,WIFI_BMP_X,WIFI_BMP_Y,WIFI_ON_LOGO);
        else showimage(WIFI_LOGO_X,WIFI_LOGO_Y,WIFI_BMP_X,WIFI_BMP_Y,WIFI_OFF_LOGO);
        break;
    /* ����ʱ�� */
    case _DATETIME:
        Gui_ShowNum(DATETIME_X,DATETIME_Y,BLACK,WHITE,DateTime.year,4);
        Gui_ShowNum(DATETIME_X+5*6,DATETIME_Y,BLACK,WHITE,DateTime.month,2);
        Gui_ShowNum(DATETIME_X+8*6,DATETIME_Y,BLACK,WHITE,DateTime.day,2);
        Gui_ShowNum(DATETIME_X+12*6,DATETIME_Y,BLACK,WHITE,DateTime.hour,2);
        Gui_ShowNum(DATETIME_X+15*6,DATETIME_Y,BLACK,WHITE,DateTime.minute,2);
        break;
    /* �յ���Դ */
    case _AIR_POWER:
        if(Air_Control.power)Gui_DrawFont_GBK12(AIR_POWER_X+(12*2+6),AIR_POWER_Y,BLACK,WHITE,"��");
        else 
        {
            Gui_DrawFont_GBK12(AIR_POWER_X+(12*2+6),AIR_POWER_Y,BLACK,WHITE,"�ر�");
            Gui_ShowNum(TIMING_X+(12*2+6),TIMING_Y,BLACK,WHITE,Air_Control.timing,1);
            Gui_ShowNum(INTERVAL_TIMING_X+(12*2+6),INTERVAL_TIMING_Y,BLACK,WHITE,Air_Control.interval_timing,1);
        }
        break;
    /* ɨ�� */
    case _SWEEP_WIND:
        if(Air_Control.wind_direct)Gui_DrawFont_GBK12(SWEEP_WIND_X+(12*2+6),SWEEP_WIND_Y,BLACK,WHITE,"��");
        else Gui_DrawFont_GBK12(SWEEP_WIND_X+(12*2+6),SWEEP_WIND_Y,BLACK,WHITE,"�ر�");
        break;
    /* �ƹ� */
    case _LIGHT:
        if(Air_Control.light)Gui_DrawFont_GBK12(LIGHT_X+(12*2+6),LIGHT_Y,BLACK,WHITE,"��");
        else Gui_DrawFont_GBK12(LIGHT_X+(12*2+6),LIGHT_Y,BLACK,WHITE,"�ر�");
        break;
    /* ģʽ */
    case _MODE:
        switch(Air_Control.mode)
        {
            case AIR_MODE_AUTO:Gui_DrawFont_GBK12(MODE_X+12*2+6,MODE_Y,BLACK,WHITE,"�Զ�");break;
            case AIR_MODE_COLD:Gui_DrawFont_GBK12(MODE_X+12*2+6,MODE_Y,BLACK,WHITE,"����");break;
            case AIR_MODE_DRY: Gui_DrawFont_GBK12(MODE_X+12*2+6,MODE_Y,BLACK,WHITE,"��ʪ");break;
            case AIR_MODE_WIND:Gui_DrawFont_GBK12(MODE_X+12*2+6,MODE_Y,BLACK,WHITE,"�ͷ�");break;
            case AIR_MODE_HOT: Gui_DrawFont_GBK12(MODE_X+12*2+6,MODE_Y,BLACK,WHITE,"����");break;
            default:rt_kprintf("[%-16s]:Refresh Air_Control.mode error,Air_Control.mode = %d.\n",rt_thread_self()->parameter,Air_Control.mode);break;
        }
        break;
    /* ���� */
    case _WIND_SPEED:
        Gui_ShowNum(WIND_SPEED_X+(12*2+6),WIND_SPEED_Y,BLACK,WHITE,Air_Control.wind_speed,1);
        break;
    /* �յ��¶� */
    case _AIR_TEMP:
        Gui_ShowNum(AIR_TEMP_X+(12*2+6),AIR_TEMP_Y,BLACK,WHITE,Air_Control.temperature,2);
        break;
    /* ��ʱ�������ʱ */
    case _TIMING:
        Gui_ShowNum(TIMING_X+(12*2+6),TIMING_Y,BLACK,WHITE,Air_Control.timing,1);
        Gui_ShowNum(INTERVAL_TIMING_X+(12*2+6),INTERVAL_TIMING_Y,BLACK,WHITE,Air_Control.interval_timing,1);
        break;
    /* ������ʪ�� */
    case _ROOM_TEMP_HUMI:
        Gui_ShowNum(ROOM_TEMP_X+(12*4+6),ROOM_TEMP_Y,BLACK,WHITE,g_temperature,2);
        Gui_ShowNum(ROOM_HUMI_X+(12*4+6),ROOM_HUMI_Y,BLACK,WHITE,g_humidity,2);
        break;
    default:
        rt_kprintf("[%-16s]:Refresh type error,buf = %d.\n",rt_thread_self()->parameter,refresh_type);
        break;
    }
}

/**
  ******************************************************************************
  * @name   : LCD_LED_Timeout
  * @brief  : LCD���ⶨʱ��,���ڿ���LCD��������ʱ��
  * @note   : ��������ʱ��Ϊ60��
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-25     YMH
  ******************************************************************************
 */
void LCD_LED_Timeout(void* parameter)
{
    LCD_LED_CLR;   //����LCD������
    rt_kprintf("[LCD_LED_Timer]:LCD LED Timer timeout,LCD LED is off\n");
}

/**
  ******************************************************************************
  * @name   : lcd_thread_entry
  * @brief  : LCD�߳�
  * @note   :
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-09     YMH
  * V1.0.1       2020-02-25     YMH          �������������ʾ����;���������յ�������ˢ����ʾ
  ******************************************************************************
 */
void lcd_thread_entry(void* parameter)
{
    uint8_t buf=0;
    rt_thread_mdelay(2500);
    Lcd_Clear(WHITE);
    /* WIFI_OFF_LOGO��ʾ */
    showimage(WIFI_LOGO_X,WIFI_LOGO_Y,WIFI_BMP_X,WIFI_BMP_Y,WIFI_OFF_LOGO);
    /* ����ʱ����ʾ */
    Gui_DrawFont_GBK12(DATETIME_X,DATETIME_Y,BLACK,WHITE,"0000-00-00  00:00");
    /* �յ�ѡ����ʾ */
    Gui_DrawFont_GBK12(AIR_POWER_X,AIR_POWER_Y,BLACK,WHITE,"��Դ:�ر�");
    Gui_DrawFont_GBK12(SWEEP_WIND_X,SWEEP_WIND_Y,BLACK,WHITE,"ɨ��:��");
    Gui_DrawFont_GBK12(LIGHT_X,LIGHT_Y,BLACK,WHITE,"�ƹ�:��");
    Gui_DrawFont_GBK12(MODE_X,MODE_Y,BLACK,WHITE,"ģʽ:����");
    Gui_DrawFont_GBK12(WIND_SPEED_X,WIND_SPEED_Y,BLACK,WHITE,"����:5 ��");
    Gui_DrawFont_GBK12(AIR_TEMP_X,AIR_TEMP_Y,BLACK,WHITE,"�¶�:25 ��");
    Gui_DrawFont_GBK12(TIMING_X,TIMING_Y,BLACK,WHITE,"��ʱ:0 ʱ");
    Gui_DrawFont_GBK12(INTERVAL_TIMING_X,INTERVAL_TIMING_Y,BLACK,WHITE,"���:0 ʱ");
    Gui_DrawFont_GBK12(ROOM_TEMP_X,ROOM_TEMP_Y,BLACK,WHITE,"�����¶�:00 ��C");
    Gui_DrawFont_GBK12(ROOM_HUMI_X,ROOM_HUMI_Y,BLACK,WHITE,"����ʪ��:00 %RH");
    while(1)
    {
        if(rt_mq_recv(&lcd_refresh_mq, &buf, sizeof(buf), RT_WAITING_FOREVER) == RT_EOK)
        {
            rt_kprintf("[lcd_refresh_mq]:lcd thread take a lcd refresh mq success.\n");
            rt_kprintf("[%-16s]:Refresh type: %d.\n",rt_thread_self()->parameter,buf);
            /* ����lcd_refresh_mq��Ϣ���еõ������ݣ�ȥ����LCD��ʾ���� */
            Refresh_LCD_Display(buf);
        }
        else rt_kprintf("[lcd_refresh_mq]:lcd thread take a lcd refresh mq failed.\n");
    }
}
