#include <rtthread.h>
#include <rthw.h>
#include "remote.h"
#include "led.h"
#include "QDTFT_demo.h"

/* �յ�����ȫ�ֱ��� */
AIRCONTROL Air_Control;
uint8_t g_timing_timer_running = 0;   /* �յ���ʱ��ʱ����������,������1,Ĭ��Ϊ0 */
rt_sem_t remote_sem = RT_NULL;
uint8_t g_power_is_off = 1;   /* Ĭ�Ͽյ���Դ�Ѿ��ر� */

/* �յ�����ȫ�ֱ�����ʼ��
ǰ35λ������-->0x8290040A
1000 0010 1001 0000 0000 0100 0000 1010 010   ����+��Դ��+�Զ�����+����ɨ��+25��+�ƹ�

��32λ������-->0x80040006
1000 0000 0000 0100 0000 0000 0000 0110       ����ɨ��+У����
                                              У���룺ģʽ+�¶�+����*8-4
ǰ35λ������-->0x829004EA
1000 0010 1001 0000 0000 0100 0000 1110 010

��32λ������-->0x00000003
0000 0000 0000 0000 0000 0000 0000 0011       
                                              У���룺ģʽ+�¶�+����+����*8-6
*/

/**
  ******************************************************************************
  * @name   : LED_Init
  * @brief  : ���ƺ����ز���Ч���IO�ڳ�ʼ��
  * @note   : ���ƺ����ز���Ч�����ʱ��
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2019-12-08     YMH          ʵ�ֹ���
  ******************************************************************************
 */
void Infrared_Control_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
}

/**
  ******************************************************************************
  * @name   : Infrared_Carrier_Init
  * @brief  : �����ز���ʼ��
  * @note   : TIM5_CH1,72000/(1889+1) = 37.9kHz
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2019-12-08     YMH          ʵ�ֹ���
  * V1.0.1       2020-01-31     YMH          �յ�����ȫ�ֱ�����ʼ��
  ******************************************************************************
 */
void Infrared_Carrier_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_OCInitTypeDef  TIM_OCInitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 ;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    TIM_TimeBaseStructure.TIM_Period = 1889;
    TIM_TimeBaseStructure.TIM_Prescaler = 0;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM5, &TIM_TimeBaseStructure);

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC1Init(TIM5,&TIM_OCInitStructure);

    TIM_Cmd(TIM5,ENABLE);
    /* 38.9kHz�ز���� */
    TIM_SetCompare1(TIM5,688);
    /* ���ƺ����ز���Ч���IO�ڳ�ʼ�� */
    Infrared_Control_Init();
    /* �յ�����ȫ�ֱ�����ʼ�� */
    Air_Control.power = AIR_POWER_OFF;
    Air_Control.mode = AIR_MODE_COLD;
    Air_Control.wind_speed = AIR_WIND_SPEED_FIVE;
    Air_Control.wind_direct = AIR_WIND_DIRECT_ON;
    Air_Control.temperature = 25;
    Air_Control.timing = 0;
    Air_Control.light = AIR_LIGHT_ON;
    Air_Control.interval_timing = 0;
}

/**
  ******************************************************************************
  * @name   : delay_us
  * @brief  : ��ʹ��ϵͳ���ӳٺ���,���Ȳ���
  * @note   : 
  * @param  : nTimer: �ӳ�ʱ��(��λ:us)
  * @retval : 
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-22     YMH
  ******************************************************************************
 */
void delay_us(u32 nTimer)
{
	u32 i=0;
	for(i=0;i<nTimer;i++)
    {
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
	}
}

/**
  ******************************************************************************
  * @name   : Output_Level
  * @brief  : ���ƺ����ز���Ч�����ʱ��
  * @note   :
  * @param  : level: �����ƽ
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-01-29     YMH          ��װΪһ������
  * V1.0.1       2020-02-22     YMH          �޸��ӳٺ���,ϵͳ�ӳٺ������Ȳ���
  ******************************************************************************
 */
void Output_Level(uint8_t level)
{
    switch(level)
    {
    /* 1��640us����+1669us�͵�ƽ */
    case HIGH_LEVEL:
        OUT=1;
        delay_us(640);
        OUT=0;
        delay_us(1669);
        break;

    /* 0��640us����+567us�͵�ƽ */
    case LOW_LEVEL:
        OUT=1;
        delay_us(640);
        OUT=0;
        delay_us(567);
        break;

    /* ��ʼ��S��8980us����+4502us�͵�ƽ */
    case S_CONNECTION_CODE:
        OUT=1;
        delay_us(8980);
        OUT=0;
        delay_us(4500);
        break;

    /* ������C1��639us����+20000us�͵�ƽ */
    case C1_CONNECTION_CODE:
        OUT=1;
        delay_us(639);
        OUT=0;
        delay_us(20000);
        break;

    /* ������C2��630us����+40020us�͵�ƽ */
    case C2_CONNECTION_CODE:
        OUT=1;
        delay_us(630);
        OUT=0;
        delay_us(40000);
        break;
    
    default:
        rt_kprintf("[%-16s]:Output Level ERROR! \n",rt_thread_self()->parameter);
        break;
    }
}

/**
  ******************************************************************************
  * @name   : Bit_Reverse_Order
  * @brief  : λ����
  * @note   :
  * @param  : *data����Ҫ��λ�������
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-02     YMH
  ******************************************************************************
 */
uint8_t Reverse_Bit(uint8_t data)
{
    uint8_t i = 8;
    uint8_t temp = data;

    while (i--)
    {
        data = data << 1;
        data &= ~1;
        if (temp & 1)
        {
            data |= 1;
        }
        temp = temp >> 1;
    }
    return data;
}

/**
  ******************************************************************************
  * @name   : Send_Each_Bit_Cyclically
  * @brief  : ѭ���ط���ѭ�����ÿһλ
  * @note   :
  * @param  : datacode: 32λ������
  * @retval :
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-02     YMH
  ******************************************************************************
 */
void Send_Each_Bit_Cyclically(uint32_t datacode)
{
    uint8_t temp_code = 0;
    uint8_t i;
#ifdef REMOTE_TEST
    for(i=0; i<32; i++)
    {
        temp_code = (datacode&0x80000000)>>31;
        if(i%4 == 0) rt_kprintf(" ");
        rt_kprintf("%d",temp_code);
        Output_Level(temp_code);
        datacode<<=1;
    }
    rt_kprintf("\n");
#else
    for(i=0; i<32; i++)
    {
        temp_code = (datacode&0x80000000)>>31;
        Output_Level(temp_code);
        datacode<<=1;
    }
#endif
}

/**
  ******************************************************************************
  * @name   : Change_To_Infrared_Coding
  * @brief  : ת��Ϊ�յ��������
  * @note   :
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-01-29     YMH
  * V1.0.0       2020-02-22     YMH          �޸���32Ϊ������[64:67]λУ�����������
  ******************************************************************************
 */
void Change_To_Infrared_Coding(uint32_t *f_35_datacode,uint32_t *f_32_datacode,
                               uint32_t *l_35_datacode,uint32_t *l_32_datacode)
{
    uint8_t check_code=0;
    /* �յ���Դ */
    (Air_Control.power == 1) ? (setbit(*f_35_datacode,AIR_POWER_BIT),setbit(*l_35_datacode,AIR_POWER_BIT)) :
    (clrbit(*f_35_datacode,AIR_POWER_BIT),clrbit(*l_35_datacode,AIR_POWER_BIT));
    /* ɨ��*/
    (Air_Control.wind_direct == 1) ? (setbit(*f_35_datacode,AIR_WIND_DIRECT_BIT),setbit(*l_35_datacode,AIR_WIND_DIRECT_BIT),setbit(*f_32_datacode,AIR_WIND_DIRECT_BIT2)) :
    (clrbit(*f_35_datacode,AIR_WIND_DIRECT_BIT),clrbit(*l_35_datacode,AIR_WIND_DIRECT_BIT),clrbit(*f_32_datacode,AIR_WIND_DIRECT_BIT2));
    /* �ƹ� */
    (Air_Control.light == 1) ? (setbit(*f_35_datacode,AIR_LIGHT_BIT),setbit(*l_35_datacode,AIR_LIGHT_BIT)) :
    (clrbit(*f_35_datacode,AIR_LIGHT_BIT),clrbit(*l_35_datacode,AIR_LIGHT_BIT));
    /* ģʽ */
    *f_35_datacode &= 0x1FFFFFFF;
    *l_35_datacode &= 0x1FFFFFFF;
    *f_35_datacode |= (uint32_t)(Reverse_Bit(Air_Control.mode))<<24;
    *l_35_datacode |= (uint32_t)(Reverse_Bit(Air_Control.mode))<<24;
    /* �¶� */
    *f_35_datacode &= 0xFF0FFFFF;
    *l_35_datacode &= 0xFF0FFFFF;
    *f_35_datacode |= (uint32_t)(Reverse_Bit(Air_Control.temperature-16))<<16;
    *l_35_datacode |= (uint32_t)(Reverse_Bit(Air_Control.temperature-16))<<16;
    /* ��ʱ */
    *f_35_datacode &= 0xFFF00FFF;
    *l_35_datacode &= 0xFFF00FFF;
    /* ���� */
    *f_35_datacode &= 0xF3FFFFFF;   //��Ӧλ����0,����1
    *l_35_datacode &= 0xF3FFFFFF;
    *l_32_datacode &= 0xFFFFF0F0;
    switch(Air_Control.wind_speed)
    {
    case AIR_WIND_SPEED_AUTO:
        /* ��Ӧλ����0 */
        break;
    case AIR_WIND_SPEED_ONE:
        *f_35_datacode |= 0x08000000;
        *l_35_datacode |= 0x08000000;
        *l_32_datacode |= 0x00000800;
        break;
    case AIR_WIND_SPEED_TWO:
        *f_35_datacode |= 0x04000000;
        *l_35_datacode |= 0x04000000;
        *l_32_datacode |= 0x00000400;
        break;
    case AIR_WIND_SPEED_THREE:
        *f_35_datacode |= 0x0C000000;
        *l_35_datacode |= 0x0C000000;
        *l_32_datacode |= 0x00000C00;
        break;
    case AIR_WIND_SPEED_FOUR:
        *f_35_datacode |= 0x0C000000;
        *l_35_datacode |= 0x0C000000;
        *l_32_datacode |= 0x00000200;
        break;
    case AIR_WIND_SPEED_FIVE:
        *f_35_datacode |= 0x0C000000;
        *l_35_datacode |= 0x0C000000;
        *l_32_datacode |= 0x00000A00;
        break;
    default:
        rt_kprintf("[%-16s]:Air_Control.wind_speed change ERROR! \n",rt_thread_self()->parameter);
        break;
    }
    /* f_32_datacodeУ���� */
    *f_32_datacode &= 0xFFFFFFF0;  //У���룺ģʽ+�¶�+����*8-4
    check_code = (Air_Control.mode+Air_Control.temperature+(Air_Control.power*8)-4);
    check_code = Reverse_Bit(check_code<<4);
    *f_32_datacode |= (uint32_t)check_code;
    /* l_32_datacodeУ���� */
    *l_32_datacode &= 0xFFFFFFF0;  //У���룺ģʽ+�¶�+����+����*8-6
    check_code = (Air_Control.mode+Air_Control.temperature+Air_Control.wind_speed+(Air_Control.power*8)-6);
    check_code = Reverse_Bit(check_code<<4);
    *l_32_datacode |= (uint32_t)check_code;
    rt_kprintf("[%-16s]:Change to the infrared coding success\n",rt_thread_self()->parameter);
}

/**
  ******************************************************************************
  * @name   : Emit_Infrared
  * @brief  : ���������
  * @note   :
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-02     YMH
  ******************************************************************************
 */
void Emit_Infrared(void)
{
    static uint32_t f_35_datacode = 0x8290040A,
                    f_32_datacode = 0x80040006,
                    l_35_datacode = 0x8290040E,
                    l_32_datacode = 0x00000003;
    /* ת��Ϊ�յ�������� */
    Change_To_Infrared_Coding(&f_35_datacode,&f_32_datacode,&l_35_datacode,&l_32_datacode);
    rt_kprintf("[%-16s]:Change_To_Infrared_Coding.\n",rt_thread_self()->parameter);
    /* S��ʼ�� */
    Output_Level(S_CONNECTION_CODE);
    /* ǰ35λ������ */
    Send_Each_Bit_Cyclically(f_35_datacode);
    Output_Level(LOW_LEVEL);
    Output_Level(HIGH_LEVEL);
    Output_Level(LOW_LEVEL);

    /* ������C1 */
    Output_Level(C1_CONNECTION_CODE);

    /* ��32λ������ */
    Send_Each_Bit_Cyclically(f_32_datacode);

    /* ������C2 */
    Output_Level(C2_CONNECTION_CODE);

    /* S��ʼ�� */
    Output_Level(S_CONNECTION_CODE);

    /* ��35λ������ */
    Send_Each_Bit_Cyclically(l_35_datacode);
    Output_Level(LOW_LEVEL);
    Output_Level(HIGH_LEVEL);
    Output_Level(LOW_LEVEL);
    

    /* ������C1 */
    Output_Level(C1_CONNECTION_CODE);

    /* ��32λ������ */
    Send_Each_Bit_Cyclically(l_32_datacode);
    Output_Level(LOW_LEVEL);
}

/**
  ******************************************************************************
  * @name   : Air_Interval_Timeout
  * @brief  : �յ������ʱ��ʱ����ʱ����
  * @note   : 
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-14     YMH
  ******************************************************************************
 */
void Air_Interval_Timeout(void* parameter)
{
    rt_err_t result;
    uint8_t buf = 0;
    static uint16_t timer_count = 0;   /* ��ʱ���ۼƼ�ʱʱ������λ(����) */
    timer_count++;
    rt_kprintf("[Air_Interval_Timer]:Air Interval Timer timing duration = %d minute.\n",timer_count);
    /* ��������ʱ��ʱ��,ֹͣ��ʱ�� */
    if(timer_count == Air_Control.interval_timing*60 || Air_Control.interval_timing ==0)
    {
        timer_count = 1;
        Air_Control.interval_timing = 0;
        /* ˢ��LCD��Ļ��ʾ */
        buf = _AIR_POWER;
        result = rt_mq_send(&lcd_refresh_mq,&buf,sizeof(buf));
        if (result != RT_EOK)
        {
            rt_kprintf("[lcd_refresh_mq]:lcd_refresh_mq send ERR,buf = _AIR_POWER.\n");
        }
        buf = _TIMING;
        result = rt_mq_send(&lcd_refresh_mq,&buf,sizeof(buf));
        if (result != RT_NULL)
        {
            rt_kprintf("[lcd_refresh_mq]:lcd_refresh_mq send ERR,buf =  _TIMING.\n");
        }
        /* ֹͣ��ʱ�� */
        g_timing_timer_running = 0;
        result = rt_timer_stop(Air_Interval_Timer);
        if(result == RT_EOK)
        {
            rt_kprintf("[Air_Interval_Timer]:Air Interval Timer has stopped.\n");
        }
    }
    /* ������ʱ�� */                 
    if((timer_count % INTERVAL) == 0)
    {
        /* �յ�����ѭ���л� */
        (Air_Control.power ==1) ? (Air_Control.power = 0) : (Air_Control.power = 1,g_power_is_off = 0);
        rt_kprintf("[Air_Interval_Timer]:Air_Control.power = %d.\n",Air_Control.power);
        /* �ͷ��ź�������������� */
        rt_sem_release(remote_sem);
        /* ˢ��LCD��Ļ��ʾ */
        buf = _AIR_POWER;
        result = rt_mq_send(&lcd_refresh_mq,&buf,sizeof(buf));
        if (result != RT_EOK)
        {
            rt_kprintf("[lcd_refresh_mq]:lcd_refresh_mq send ERR,buf = _AIR_POWER.\n");
        }
    }
}

/**
  ******************************************************************************
  * @name   : Air_Timing_Timeout
  * @brief  : �յ���ʱ��ʱ����ʱ����
  * @note   : 
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-26     YMH
  ******************************************************************************
 */
void Air_Timing_Timeout(void* parameter)
{
    rt_err_t result;
    uint8_t buf = 0;
    static uint16_t timer_count = 0;   /* ��ʱ���ۼƼ�ʱʱ������λ(����) */
    timer_count++;
    rt_kprintf("[Air_Timing_Timer]:Air Timing Timer timing duration = %d minute.\n",timer_count);
    /* ��ʱ��ʱ���ﵽ,ֹͣ��ʱ��,��������߹رտյ� */
    if(timer_count == (Air_Control.timing*60))
    {
        timer_count = 0;   //ʱ������
        /* �رտյ� */
        Air_Control.timing = 0;
        Air_Control.power = AIR_POWER_OFF;
        rt_sem_release(remote_sem);
        /* ˢ��LCD��Ļ��ʾ */
        buf = _AIR_POWER;
        result = rt_mq_send(&lcd_refresh_mq,&buf,sizeof(buf));
        if (result != RT_EOK)
        {
            rt_kprintf("[lcd_refresh_mq]:lcd_refresh_mq send ERR,buf = _AIR_POWER.\n");
        }
        buf = _TIMING;
        result = rt_mq_send(&lcd_refresh_mq,&buf,sizeof(buf));
        if (result != RT_NULL)
        {
            rt_kprintf("[lcd_refresh_mq]:lcd_refresh_mq send ERR,buf =  _TIMING.\n");
        }
        /* ֹͣ��ʱ�� */
        g_timing_timer_running = 0;
        result = rt_timer_stop(Air_Timing_Timer);
        if(result == RT_EOK)
        {
            rt_kprintf("[Air_Timing_Timer]:Air Timing Timer has stopped.\n");
            return;
        }
    }
    /* ��ʱ��ʱ����������,ֹͣ��ʱ�� */
    if(Air_Control.timing == 0)
    {
        timer_count = 0;   //ʱ������
        g_timing_timer_running = 0;
        result = rt_timer_stop(Air_Timing_Timer);
        if(result == RT_EOK)
        {
            rt_kprintf("[Air_Timing_Timer]:Air Timing Timer has stopped.\n");
        }
    } 
}

/**
  ******************************************************************************
  * @name   : remote_thread_entry
  * @brief  : ���ⷢ���߳�
  * @note   : ���remote_sem�ź����ͷ��������
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-02-14     YMH
  * V1.0.0       2020-02-22     YMH          ���Ӻ��ⷢ������,��֤�ڵ�Դ�رյ������,�����������
  * V1.0.1       2020-02-26     YMH          �ڷ��������ǰ�������ٽ���,��ֹ���䱻���,����ʧ��
  ******************************************************************************
 */
void remote_thread_entry(void* parameter)
{
    rt_err_t result;
    rt_base_t level;

    while(1)
    {
        result = rt_sem_take(remote_sem, RT_WAITING_FOREVER);
        if (result == RT_EOK)
        {
            rt_kprintf("[remote_sem]:Remote thread take a remote semaphore success.\n");
            /* �жϿյ���Դ�Ƿ�� */
            if(g_power_is_off == 0)
            {
                level = rt_hw_interrupt_disable();    //�����ٽ������˳�ǰϵͳ���ᷢ���������
                /* ��������� */
                Emit_Infrared();
                rt_hw_interrupt_enable(level);    //�˳��ٽ���
                rt_kprintf("[%-16s]:Emit infrared success......\n",rt_thread_self()->parameter);
                if(Air_Control.power == AIR_POWER_OFF)g_power_is_off =1;    //�յ���Դ�Ѿ��ر�
            }
            else 
                rt_kprintf("[%-16s]:Emit infrared failed,Because the air conditioner power is off\n",rt_thread_self()->parameter);
        }
        else
        {
            rt_kprintf("[%-16s]:Remote thread take a remote semaphore failed.\n",rt_thread_self()->parameter);
        }
    }
}

/*1��640us����+1670us�͵�ƽ*/
void High_Level(void)
{
    OUT=1;
    delay_us(640);
    OUT=0;
    delay_us(1669);
}
/*0��640us����+568us�͵�ƽ*/
void Low_Level(void)
{
    OUT=1;
    delay_us(640);
    OUT=0;
    delay_us(567);
}

/* ��ʼ��S��9000us����+4500us�͵�ƽ */
void S_Connection_Code(void)
{
    OUT=1;
    delay_us(8980);
    OUT=0;
    delay_us(4502);
}
/*������C1��640us����+20000us�͵�ƽ*/
void C1_Connection_Code(void)
{
    OUT=1;
    delay_us(639);
    OUT=0;
    delay_us(20000);
}
/*������C2��640us����+40000us�͵�ƽ*/
void C2_Connection_Code(void)
{
    OUT=1;
    delay_us(630);
    OUT=0;
    delay_us(40020);
}

