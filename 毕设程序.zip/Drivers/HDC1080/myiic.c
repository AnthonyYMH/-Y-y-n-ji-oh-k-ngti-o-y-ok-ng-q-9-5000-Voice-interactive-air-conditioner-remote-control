#include <rtthread.h>
#include "myiic.h"

/**
  ******************************************************************************
  * @name   : IIC_Init
  * @brief  : ��ʼ��IIC��IO��
  * @note   :
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2019-12-04     YMH          �޸ĸ�ʽ
  ******************************************************************************
 */
void IIC_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(	RCC_APB2Periph_GPIOB, ENABLE );

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP ;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    IIC_SCL=1;
    IIC_SDA=1;
}

/**
  ******************************************************************************
  * @name   : IIC_Start
  * @brief  : ����IIC��ʼ�ź�
  * @note   :
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2019-12-04     YMH          �޸ĸ�ʽ
  ******************************************************************************
 */
void IIC_Start(void)
{
    SDA_OUT();
    IIC_SDA=1;
    IIC_SCL=1;
    rt_thread_udelay(5);
    IIC_SDA=0;
    rt_thread_udelay(5);
    IIC_SCL=0;
}

/**
  ******************************************************************************
  * @name   : IIC_Stop
  * @brief  : ����IICֹͣ�ź�
  * @note   :
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2019-12-04     YMH          �޸ĸ�ʽ
  ******************************************************************************
 */
void IIC_Stop(void)
{
    SDA_OUT();
    IIC_SCL=0;
    IIC_SDA=0;
    rt_thread_udelay(5);
    IIC_SCL=1;
    IIC_SDA=1;
    rt_thread_udelay(5);
}

/**
  ******************************************************************************
  * @name   : IIC_Wait_Ack
  * @brief  : �ȴ�Ӧ���źŵ���
  * @note   :
  * @param  : None
  * @retval : 1->����Ӧ��ʧ��
  *           0->����Ӧ��ɹ�
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2019-12-04     YMH          �޸ĸ�ʽ
  ******************************************************************************
 */
u8 IIC_Wait_Ack(void)
{
    u8 ucErrTime=0;
    SDA_IN();
    IIC_SDA=1;
    rt_thread_udelay(2);
    IIC_SCL=1;
    rt_thread_udelay(2);
    while(READ_SDA)
    {
        ucErrTime++;
        if(ucErrTime>250)
        {
            IIC_Stop();
            return 1;
        }
    }
    IIC_SCL=0;
    return 0;
}

/**
  ******************************************************************************
  * @name   : IIC_Ack
  * @brief  : ����ACKӦ���ź�
  * @note   :
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2019-12-04     YMH          �޸ĸ�ʽ
  ******************************************************************************
 */
void IIC_Ack(void)
{
    IIC_SCL=0;
    SDA_OUT();
    IIC_SDA=0;
    rt_thread_udelay(3);
    IIC_SCL=1;
    rt_thread_udelay(3);
    IIC_SCL=0;
}

/**
  ******************************************************************************
  * @name   : IIC_NAck
  * @brief  : ������ACKӦ���ź�
  * @note   :
  * @param  : None
  * @retval :
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2019-12-04     YMH          �޸ĸ�ʽ
  ******************************************************************************
 */
void IIC_NAck(void)
{
    IIC_SCL=0;
    SDA_OUT();
    IIC_SDA=1;
    rt_thread_udelay(3);
    IIC_SCL=1;
    rt_thread_udelay(3);
    IIC_SCL=0;
}

/**
  ******************************************************************************
  * @name   : IIC_Send_Byte
  * @brief  : ����һ���ֽ�
  * @note   : 
  * @param  : txd: ���شӻ�����Ӧ��
  *           1->��Ӧ��
  *           0->��Ӧ��
  * @retval : 
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2019-12-04     YMH          �޸ĸ�ʽ
  ******************************************************************************
 */
void IIC_Send_Byte(u8 txd)
{
    u8 t;
    SDA_OUT();
    IIC_SCL=0;       
    for(t=0; t<8; t++)
    {
        /* �����λ��ʼ��λ���� */
        IIC_SDA=(txd&0x80)>>7;  
        txd<<=1;
        rt_thread_udelay(3);   
        IIC_SCL=1;     
        rt_thread_udelay(3);
        IIC_SCL=0;
        rt_thread_udelay(3);
    }
}

/**
  ******************************************************************************
  * @name   : IIC_Read_Byte
  * @brief  : ��ȡһ���ֽ�
  * @note   : 
  * @param  : ack: �Ƿ���ACKӦ���ź�
  *           1->����ACK
  *           0->����nACK
  * @retval : 
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2019-12-04     YMH          �޸ĸ�ʽ
  ******************************************************************************
 */
u8 IIC_Read_Byte(unsigned char ack)
{
    unsigned char i,receive=0;
    SDA_IN();  
    for(i=0; i<8; i++ )
    {
        IIC_SCL=0;
        rt_thread_udelay(3);
        IIC_SCL=1;
        receive<<=1;
        if(READ_SDA)receive++;
        rt_thread_udelay(2);
    }
    if (!ack)
        IIC_NAck();
    else
        IIC_Ack(); 
    return receive;
}



























