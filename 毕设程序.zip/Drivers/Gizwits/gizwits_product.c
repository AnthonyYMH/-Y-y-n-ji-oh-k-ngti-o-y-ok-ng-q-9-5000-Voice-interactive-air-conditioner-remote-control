/**
************************************************************
* @file         gizwits_product.c
* @brief        Gizwits control protocol processing, and platform-related hardware initialization
* @author       Gizwits
* @date         2017-07-19
* @version      V03030000
* @copyright    Gizwits
*
* @note         Gizwits is only for smart hardware
*               Gizwits Smart Cloud for Smart Products
*               Links | Value Added | Open | Neutral | Safety | Own | Free | Ecology
*               www.gizwits.com
*
***********************************************************/
#include <stdio.h>
#include <string.h>
#include "usart3.h"
#include "gizwits_product.h"
#include "sys.h"
#include "timer.h"
#include "led.h"
#include "remote.h"
#include "hdc1080.h"
#include "dysv17f.h"
#include "QDTFT_demo.h"

static uint32_t timerMsCount;

/** Current datapoint */
dataPoint_t currentDataPoint;

/**@} */
/**@name Gizwits User Interface
* @{
*/

/**
* @brief Event handling interface

* Description:

* 1. Users can customize the changes in WiFi module status

* 2. Users can add data points in the function of event processing logic, such as calling the relevant hardware peripherals operating interface

* @param [in] info: event queue
* @param [in] data: protocol data
* @param [in] len: protocol data length
* @return NULL
* @ref gizwits_protocol.h
*/
int8_t gizwitsEventProcess(eventInfo_t *info, uint8_t *gizdata, uint32_t len)
{
    uint8_t buf = 0;
    rt_err_t result;
    uint8_t i = 0;
    dataPoint_t *dataPointPtr = (dataPoint_t *)gizdata;
    moduleStatusInfo_t *wifiData = (moduleStatusInfo_t *)gizdata;
    protocolTime_t *ptime = (protocolTime_t *)gizdata;

#if MODULE_TYPE
    gprsInfo_t *gprsInfoData = (gprsInfo_t *)gizdata;
#else
    moduleInfo_t *ptModuleInfo = (moduleInfo_t *)gizdata;
#endif

    if((NULL == info) || (NULL == gizdata))
    {
        return -1;
    }
    /*
        ---1.定时与间隔定时不能同时不为0,比如：设置了定时,那么间隔定时就要为0
        ---2.空调电源在关闭的情况下,不发射红外线
        ---3.只有在电源打开时,才能设置定时与间隔定时的时间
        ---4.电源关闭时,应该把定时与间隔定时的时间清零
    */
    for(i=0; i<info->num; i++)
    {
        switch(info->event[i])
        {
        /* 夜灯 */
        case EVENT_LED:
            currentDataPoint.valueLED = dataPointPtr->valueLED;
            GIZWITS_LOG("[GIZWITS_LOG]:Evt: EVENT_LED %d \n", currentDataPoint.valueLED);
            if(0x01 == currentDataPoint.valueLED)
            {
                LED = LEDON;
                g_led = 1;
                Response_Sound(_DING_DING);
            }
            else
            {
                LED = LEDOFF;
                g_led = 0;
                Response_Sound(_DING_DING);
            }
            break;
        /* 空调电源 */
        case EVENT_Air_Power:
            currentDataPoint.valueAir_Power = dataPointPtr->valueAir_Power;
            GIZWITS_LOG("[GIZWITS_LOG]:Evt: EVENT_Air_Power %d \n", currentDataPoint.valueAir_Power);
            if(0x01 == currentDataPoint.valueAir_Power)
            {
                Air_Control.power = AIR_POWER_ON;
                buf = _AIR_POWER;
                Response_Sound(_DING_DING);
                g_power_is_off = 0;   //空调电源已经打开
                rt_sem_release(remote_sem);
            }
            else
            {
                Air_Control.power = AIR_POWER_OFF;
                Air_Control.timing = 0;Air_Control.interval_timing = 0;
                buf = _AIR_POWER;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
            }
            break;
        /* 扫风 */
        case EVENT_Air_Wind_Direct:
            currentDataPoint.valueAir_Wind_Direct = dataPointPtr->valueAir_Wind_Direct;
            GIZWITS_LOG("[GIZWITS_LOG]:Evt: EVENT_Air_Wind_Direct %d \n", currentDataPoint.valueAir_Wind_Direct);
            if(0x01 == currentDataPoint.valueAir_Wind_Direct)
            {
                Air_Control.wind_direct = AIR_WIND_DIRECT_ON;
                buf = _SWEEP_WIND;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
            }
            else
            {
                Air_Control.wind_direct = AIR_WIND_DIRECT_OFF;
                buf = _SWEEP_WIND;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
            }
            break;
        /* 灯光 */
        case EVENT_Air_Light:
            currentDataPoint.valueAir_Light = dataPointPtr->valueAir_Light;
            GIZWITS_LOG("[GIZWITS_LOG]:Evt: EVENT_Air_Light %d \n", currentDataPoint.valueAir_Light);
            if(0x01 == currentDataPoint.valueAir_Light)
            {
                Air_Control.light = AIR_LIGHT_ON;
                buf = _LIGHT;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
            }
            else
            {
                Air_Control.light = AIR_LIGHT_OFF;
                buf = _LIGHT;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
            }
            break;
        /* 模式 */
        case EVENT_Air_Mode:
            currentDataPoint.valueAir_Mode = dataPointPtr->valueAir_Mode;
            GIZWITS_LOG("[GIZWITS_LOG]:Evt: EVENT_Air_Mode %d\n", currentDataPoint.valueAir_Mode);
            switch(currentDataPoint.valueAir_Mode)
            {
            case Air_Mode_VALUE0:
                Air_Control.mode = AIR_MODE_AUTO;
                buf = _MODE;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
                break;
            case Air_Mode_VALUE1:
                Air_Control.mode = AIR_MODE_COLD;
                buf = _MODE;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
                break;
            case Air_Mode_VALUE2:
                Air_Control.mode = AIR_MODE_DRY;
                buf = _MODE;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
                break;
            case Air_Mode_VALUE3:
                Air_Control.mode = AIR_MODE_WIND;
                buf = _MODE;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
                break;
            case Air_Mode_VALUE4:
                Air_Control.mode = AIR_MODE_HOT;
                buf = _MODE;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
                break;
            default:
                break;
            }
            break;
        /* 风速 */
        case EVENT_Air_Wind_Speed:
            currentDataPoint.valueAir_Wind_Speed = dataPointPtr->valueAir_Wind_Speed;
            GIZWITS_LOG("[GIZWITS_LOG]:Evt: EVENT_Air_Wind_Speed %d\n", currentDataPoint.valueAir_Wind_Speed);
            switch(currentDataPoint.valueAir_Wind_Speed)
            {
            case Air_Wind_Speed_VALUE0:
                Air_Control.wind_speed = AIR_WIND_SPEED_AUTO;
                buf = _WIND_SPEED;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
                break;
            case Air_Wind_Speed_VALUE1:
                Air_Control.wind_speed = AIR_WIND_SPEED_ONE;
                buf = _WIND_SPEED;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
                break;
            case Air_Wind_Speed_VALUE2:
                Air_Control.wind_speed = AIR_WIND_SPEED_TWO;
                buf = _WIND_SPEED;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
                break;
            case Air_Wind_Speed_VALUE3:
                Air_Control.wind_speed = AIR_WIND_SPEED_THREE;
                buf = _WIND_SPEED;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
                break;
            case Air_Wind_Speed_VALUE4:
                Air_Control.wind_speed = AIR_WIND_SPEED_FOUR;
                buf = _WIND_SPEED;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
                break;
            case Air_Wind_Speed_VALUE5:
                Air_Control.wind_speed = AIR_WIND_SPEED_FIVE;
                buf = _WIND_SPEED;
                Response_Sound(_DING_DING);
                rt_sem_release(remote_sem);
                break;
            default:
                break;
            }
            break;
        /* 温度 */
        case EVENT_Air_Temperature:
            currentDataPoint.valueAir_Temperature = dataPointPtr->valueAir_Temperature;
            GIZWITS_LOG("[GIZWITS_LOG]:Evt:EVENT_Air_Temperature %d\n",currentDataPoint.valueAir_Temperature);
            Air_Control.temperature = currentDataPoint.valueAir_Temperature;
            buf = _AIR_TEMP;
            Response_Sound(_DING_DING);
            rt_sem_release(remote_sem);
            break;
        /* 定时 */
        case EVENT_Air_Timing:
            currentDataPoint.valueAir_Timing = dataPointPtr->valueAir_Timing;
            GIZWITS_LOG("[GIZWITS_LOG]:Evt:EVENT_Air_Timing %d\n",currentDataPoint.valueAir_Timing);
            /* 只有在电源打开时,才能设置定时与间隔定时的时间 */
            if(Air_Control.power == AIR_POWER_ON)
            {
                Air_Control.timing = currentDataPoint.valueAir_Timing;
                Air_Control.interval_timing = 0;
                /* 启动空调定时定时器 */
                g_timing_timer_running = 1;
                result = rt_timer_start(Air_Timing_Timer);
                if(result == RT_EOK)
                {
                    rt_kprintf("[%-16s]:Air Timing has been modified,Air Timing Timer has started up.\n",rt_thread_self()->parameter);
                }
                buf = _TIMING;
                Response_Sound(_DING_DING);
                //rt_sem_release(remote_sem);
            }
            else rt_kprintf("[GIZWITS_LOG]:Timing failure because air conditioner power is off!!!!!!\n");
            break;
        /* 间隔定时 */
        case EVENT_Air_Interval_timing:
            currentDataPoint.valueAir_Interval_timing = dataPointPtr->valueAir_Interval_timing;
            GIZWITS_LOG("[GIZWITS_LOG]:Evt:EVENT_Air_Interval_timing %d\n",currentDataPoint.valueAir_Interval_timing);
            /* 只有在电源打开时,才能设置定时与间隔定时的时间 */
            if(Air_Control.power == AIR_POWER_ON || Air_Control.interval_timing !=0)
            {
                Air_Control.interval_timing = currentDataPoint.valueAir_Interval_timing;
                Air_Control.timing =0;
                /* 启动空调间隔定时定时器 */
                g_timing_timer_running = 1;
                result = rt_timer_start(Air_Interval_Timer);
                if(result == RT_EOK)
                {
                    rt_kprintf("[%-16s]:Interval timing has been modified,Air Interval Timer has started up.\n",rt_thread_self()->parameter);
                }
                buf = _TIMING;
                Response_Sound(_DING_DING);
                //rt_sem_release(remote_sem);
            }
            else rt_kprintf("[GIZWITS_LOG]:Interval timing failure because air conditioner power is off!!!!!!\n");
            break;

        case WIFI_SOFTAP:
            break;
        case WIFI_AIRLINK:
            break;
        case WIFI_STATION:
            break;
        case WIFI_CON_ROUTER:

            break;
        case WIFI_DISCON_ROUTER:

            break;
        case WIFI_CON_M2M:
            g_wifi_sta = WIFI_CONNECT;   //WIFI连接成功
            rt_kprintf("[%-16s]:**********WIFI connection succeeded**********\n",rt_thread_self()->parameter);
            buf = _WIFI_LOGO;
            Response_Sound(_WIFI_CONNECT_SUCCESS);
            break;
        case WIFI_DISCON_M2M:
            g_wifi_sta = WIFI_DISCONNECT;   //WIFI连接失败
            rt_kprintf("[%-16s]:**********WIFI connection failed**********\n",rt_thread_self()->parameter);
            buf = _WIFI_LOGO;
            Response_Sound(_WIFI_CONNECT_FAILED);
            break;
        case WIFI_RSSI:
            GIZWITS_LOG("[GIZWITS_LOG]:RSSI %d\n", wifiData->rssi);
            break;
        case TRANSPARENT_DATA:
            GIZWITS_LOG("[GIZWITS_LOG]:TRANSPARENT_DATA \n");
            //user handle , Fetch data from [data] , size is [len]
            break;
        case WIFI_NTP:
            /* WIFI连接成功后读取才有效 */
            if(g_wifi_sta == WIFI_CONNECT)
            {
                //GIZWITS_LOG("[GIZWITS_LOG]:WIFI_NTP : [%d-%d-%d %02d:%02d:%02d][%d] \n",ptime->year,ptime->month,ptime->day,ptime->hour,ptime->minute,ptime->second,ptime->ntp);
                g_wifi_get_ntp = WIFI_GET_NTP;
                DateTime.year = ptime->year;
                DateTime.month = ptime->month;
                DateTime.day = ptime->day;
                DateTime.hour = ptime->hour;
                DateTime.minute = ptime->minute;
                DateTime.second = ptime->second;
            }
            else
            {
                rt_kprintf("[%-16s]:WIFI is not connected. \n",rt_thread_self()->parameter);
            }
            break;
        case MODULE_INFO:
            GIZWITS_LOG("[GIZWITS_LOG]:MODULE INFO ...\n");
#if MODULE_TYPE
            GIZWITS_LOG("[GIZWITS_LOG]:GPRS MODULE ...\n");
            //Format By gprsInfo_t
#else
            GIZWITS_LOG("[GIZWITS_LOG]:WIF MODULE ...\n");
            //Format By moduleInfo_t
            GIZWITS_LOG("[GIZWITS_LOG]:moduleType : [%d] \n",ptModuleInfo->moduleType);
#endif
            break;
        default:
            break;
        }
    }

    return buf;
}

/**
* User data acquisition

* Here users need to achieve in addition to data points other than the collection of data collection, can be self-defined acquisition frequency and design data filtering algorithm
* 这里用户需要实现除数据点以外的数据收集，可以自定义采集频率和设计数据过滤算法
* @param none
* @return none
*/
void userHandle(void)
{
    currentDataPoint.valueLED = g_led;
    currentDataPoint.valueAir_Power = Air_Control.power;
    currentDataPoint.valueAir_Wind_Direct = Air_Control.wind_direct;
    currentDataPoint.valueAir_Light = Air_Control.light;
    currentDataPoint.valueAir_Mode = Air_Control.mode;
    currentDataPoint.valueAir_Wind_Speed = Air_Control.wind_speed;
    currentDataPoint.valueAir_Temperature = Air_Control.temperature;
    currentDataPoint.valueAir_Timing = Air_Control.timing;
    currentDataPoint.valueAir_Interval_timing = Air_Control.interval_timing;
    currentDataPoint.valuetemperature = g_temperature;
    currentDataPoint.valuehumidity = g_humidity;
}

/**
* Data point initialization function

* In the function to complete the initial user-related data  在功能上完成初始用户相关数据
* @param none
* @return none
* @note The developer can add a data point state initialization value within this function
*/
void userInit(void)
{
    memset((uint8_t*)&currentDataPoint, 0, sizeof(dataPoint_t));
    /** Warning !!! DataPoint Variables Init , Must Within The Data Range **/
    currentDataPoint.valueLED = g_led;
    currentDataPoint.valueAir_Power = Air_Control.power;
    currentDataPoint.valueAir_Wind_Direct = Air_Control.wind_direct;
    currentDataPoint.valueAir_Light = Air_Control.light;
    currentDataPoint.valueAir_Mode = Air_Control.mode;
    currentDataPoint.valueAir_Wind_Speed = Air_Control.wind_speed;
    currentDataPoint.valueAir_Temperature = Air_Control.temperature;
    currentDataPoint.valueAir_Timing = Air_Control.timing;
    currentDataPoint.valueAir_Interval_timing = Air_Control.interval_timing;
    currentDataPoint.valuetemperature = g_temperature;
    currentDataPoint.valuehumidity = g_humidity;
}


/**
* @brief  gizTimerMs

* millisecond timer maintenance function ,Millisecond increment , Overflow to zero

* @param none
* @return none
*/
void gizTimerMs(void)
{
    timerMsCount++;
}

/**
* @brief gizGetTimerCount

* Read system time, millisecond timer

* @param none
* @return System time millisecond
*/
uint32_t gizGetTimerCount(void)
{
    return timerMsCount;
}

/**
* @brief mcuRestart

* MCU Reset function

* @param none
* @return none
*/
void mcuRestart(void)
{

}
/**@} */

/**
* @brief TIMER_IRQ_FUN

* Timer Interrupt handler function

* @param none
* @return none
*/
void TIMER_IRQ_FUN(void)
{
    gizTimerMs();
}

/**
* @brief UART_IRQ_FUN

* UART Serial interrupt function ，For Module communication

* Used to receive serial port protocol data between WiFi module

* @param none
* @return none
*/
void UART_IRQ_FUN(void)
{
    uint8_t value = 0;
    //value = USART_ReceiveData(USART2);//STM32 test demo
    gizPutData(&value, 1);
}


/**
* @brief uartWrite

* Serial write operation, send data to the WiFi module

* @param buf      : Data address
* @param len       : Data length
*
* @return : Not 0,Serial send success;
*           -1，Input Param Illegal
*/
int32_t uartWrite(uint8_t *buf, uint32_t len)
{
    uint32_t i = 0;

    if(NULL == buf)
    {
        return -1;
    }

#ifdef PROTOCOL_DEBUG
    GIZWITS_LOG("[GIZWITS_LOG]:MCU2WiFi[%4d:%4d]: ", gizGetTimerCount(), len);
    for(i=0; i<len; i++)
    {
        GIZWITS_LOG("[GIZWITS_LOG]:%02x ", buf[i]);
    }
    GIZWITS_LOG("\n");
#endif

    for(i=0; i<len; i++)
    {
        USART_SendData(USART3,buf[i]);
        while(USART_GetFlagStatus(USART3,USART_FLAG_TC)==RESET);
        if(i >=2 && buf[i] == 0xFF)
        {
            USART_SendData(USART3,0X55);
            while(USART_GetFlagStatus(USART3,USART_FLAG_TC)==RESET);
        }
    }
    return len;
}

/**
  ******************************************************************************
  * @name   : Gizwits_Init
  * @brief  : Gizwits协议初始化
  * @note   :
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2020-01-31     YMH
  ******************************************************************************
 */
void Gizwits_Init(void)
{
    TIM3_Int_Init(9,7199);   //1MS系统定时
    usart3_init(9600);   //WIFI初始化
    gizwitsInit();   //缓冲区初始化
    userInit();   //初始化数据点
    userHandle();   //上传数据点
}


