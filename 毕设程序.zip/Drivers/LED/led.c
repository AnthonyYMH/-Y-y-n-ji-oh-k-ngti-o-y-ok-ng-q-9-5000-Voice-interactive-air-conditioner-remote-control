#include "led.h"

/* LED��״̬ȫ�ֱ��� */
uint8_t g_led = 0;

/**
  ******************************************************************************
  * @name   : LED_Init
  * @brief  : Сҹ�Ƴ�ʼ��
  * @note   : ����͵�ƽ����
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2019-12-03     YMH          ʵ�ֹ���
  ******************************************************************************
 */
void LED_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
    /* Ĭ������ߵ�ƽϨ�� */
    GPIO_SetBits(GPIOC,GPIO_Pin_6);
    LED = LEDOFF;
    g_led = 0;
}

