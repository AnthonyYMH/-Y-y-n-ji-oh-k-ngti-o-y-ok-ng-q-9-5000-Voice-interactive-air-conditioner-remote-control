#include "pir.h"

/** 
  ******************************************************************************
  * @name   : PIR_Init
  * @brief  : �����Ӧģ�����IO�ڳ�ʼ��
  * @note   : 
  * @param  : None
  * @retval : None
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2019-12-08     YMH          ʵ�ֹ���
  ******************************************************************************
 */
void PIR_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; 
 	GPIO_Init(GPIOA, &GPIO_InitStructure);
} 

/**
  ******************************************************************************
  * @name   : PIR_Scan
  * @brief  : ��ȡ�����Ӧģ�����
  * @note   : Ĭ������͵�ƽ,��Ӧ������󴥷�����ߵ�ƽ
  * @param  : None 
  * @retval : PIR_YES������
  *           PIR_NO��û����
  *-----------------------------Modify information------------------------------
  * Version      Date           Author       Notes
  * V1.0.0       2019-12-08     YMH          ʵ�ֹ���(δ��֤)
  ******************************************************************************
 */
rt_int8_t PIR_Scan(void)
{	 
	if(PIR_OUT==1)
    {
        return PIR_YES;
    }
	else return PIR_NO;
}
